from .audio_downloader import main

# 在导入包时执行下载逻辑
main()
